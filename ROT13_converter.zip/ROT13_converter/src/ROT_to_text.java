import java.util.*;

public class ROT_to_text {
    public static void main(String[] args){
        Scanner s = new Scanner(System.in);

        System.out.println("*****Enter the cipher to be decode*****");

        String translate = s.nextLine();

        for(int i = 0; i<translate.length(); i++){
            char a = translate.charAt(i);
            int ascii = a;
            ascii -= 13;
            char c = (char)ascii;
            System.out.print(c);


        }

    }
}
