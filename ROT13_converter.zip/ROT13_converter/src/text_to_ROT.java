import java.util.*;

public class text_to_ROT {

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.println("Enter a string");
        String str = s.nextLine();
        System.out.println("You entered " + str);

        for(int i=0; i<str.length(); i++){
           char a = str.charAt(i);
            int ascii = a;
            ascii += 13;
            char c = (char)ascii;
            System.out.print(c);


        }





    }
}
